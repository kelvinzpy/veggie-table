import VTbackend as VT

if __name__=='__main__':
    
    # Converts excel sheet to list in script
    datasheet = VT.excelToList('testsheet.xlsx')
    outputFile = 'testoutput'

    # Opens up the PyGame interactive window
    windowSurface = VT.initScreen()
    
    # Receives input data for intended sample number (default is 0)
    try:
        sampleNum = int(VT.inputData(windowSurface))
    except ValueError:
        sampleNum = 0
        
    # Plays videos in succession
    for i in range(len(datasheet)):
        VT.vidPlayback(windowSurface, i, datasheet, sampleNum, outputFile)
                         
    # if program is run to completion (no early terminations),
    # print (datasheet)
    VT.fidcheck(datasheet, sampleNum) # does a fidelity check before program ends - check console for any errors
    VT.writefile(datasheet, sampleNum, outputFile) # writes outputs to file and terminates program


